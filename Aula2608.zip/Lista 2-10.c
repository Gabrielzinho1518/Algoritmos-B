/*10. Fa�a um programa, com uma fun��o que recebe como par�metro uma letra e uma string, e
retorne um valor inteiro indicando quantas vezes a letra aparece na string. A fun��o main deve
ler a string, a letra e chamar a fun��o implementada.*/

#include <stdio.h>
#include <string.h>
char s[50];
int contarLetra(char l){
    int i, q=0;
    for(i=0;s[i]!='\0';i++){
        if(s[i]==l) q++;
    }
    return q;
}
int main(){
    char letra;
    printf("Uma palavra:\n");
    scanf("%s",s);
    printf("Letra:");
    fflush(stdin);
    scanf("%c",&letra);
    printf("A letra %c ocorre %d vezes na palavra %s\n", letra, contarLetra(letra),s);

return 0;
}
