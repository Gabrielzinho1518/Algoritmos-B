#include <stdio.h>
float v[15];//Vari�vel global
void mostrarVetor(){
    int a;
    printf("Vetor:\n");
    for (a=0;a<15;a++){
        printf("%.0f\t",v[a]);
    }
}
void calculo(float x){
    int i;
    for (i=0; i<15; i++){
        v[i] = v[i] * x;

    }
    return;

}

int main (){
    float n;
    int i;
    printf("Digite um n�mero:");
    scanf("%f",&n);
    //gerando os elementos de v
    for (i=0; i<15; i++){
        v[i] = rand()%30;
    }
    mostrarVetor();
    calculo(n);
    mostrarVetor();

    return 0;

}



