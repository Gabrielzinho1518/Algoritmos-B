/*Escreva uma função para verificar se um determinado ano é
bissexto. Os anos bissextos são anos com um dia a mais, tendo,
portanto 366 dias. O dia extra é introduzido como o dia 29 de
fevereiro, ocorrendo a cada quatro anos. No final do século
XVI foi introduzido o calendário Gregoriano, usado até hoje na
maioria dos países, adotando as seguintes regras:
◦ Todo ano divisível por 4 é bissexto
◦ Todo ano divisível por 100 não é bissexto
◦ Mas se o ano for também divisível por 400 é bissexto
● As últimas regras prevalecem sobre as primeiras.*/
#include <stdio.h>
void bissexto(int ano){
    if(ano%400 == 0)
        printf("O Ano e bissexto\n");

    else if(ano%100 == 0)
        printf("o Ano nao e bissexto\n");
    else if (ano%4 == 0)
        printf("Bissexto");
    else
        printf("Nao e bissexto");
}

    int main(){
        int a;
        printf("Informe o ano:\n");
        scanf("%d", &a);
        bissexto(a);
        return;
}

