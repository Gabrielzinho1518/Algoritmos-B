//Lista 2-3
#include <stdio.h>

float soma(float x, float y){
 return x + y;
}
float sub(float x, float y){
 return x - y;
}
float mult(float x, float y){
 return x * y;
}
float div(float x, float y){
 return x / y;
}

int main(){
    float a, b;
    printf("Informe 2 numeros:\n");
    scanf("%f %f", &a, &b);
    printf("Soma = %.2f\n", soma(a,b));
    printf("Subtracao = %.2f\n", sub(a,b));
    printf("Multiplicacao = %.2f\n", mult(a,b));
    printf("Divisao = %.2f\n", div(a,b));

 return 0;
}
