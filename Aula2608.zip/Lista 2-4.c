/*8. Desenvolva um programa para ler as notas 1, 2 e 3 de um estudante. Em uma fun��o, calcule a
m�dia aritm�tica do estudante.*/

#include <stdio.h>
float media(float a, float b, float c){
    return (a + b + c)/3;
}

int main(){
    float a, b, c;
    printf("Digite suas 3 notas:\n");
    scanf("%f%f%f", &a, &b, &c);
    printf("Sua media aritmetica:%f\n", media(a,b,c));


return 0;
}

