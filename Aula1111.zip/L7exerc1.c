//Fazer a soma de dois vetores alocados dinamicamente. O tamanho dos vetores � informado pelo usu�rio
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main(){
    int *a, int *t;
    float *s, *vetorA, *vetorB;

    printf("Digite o tamanho dos vetores:\n");
    scanf("%d", &t);

    vetorA = (float *) malloc(t* sizeof(float));
    if (!vetorA) {
        printf("Erro ao alocar mem�ria!\n");
        exit(-1);
    }
    vetorB = (float *) malloc(t* sizeof(float));
    if (!vetorB) {
        printf("Erro ao alocar mem�ria!\n");
        exit(-1);
    }
    vetSoma = (float *) malloc(t* sizeof(float));
    if (!vetSoma) {
        printf("Erro ao alocar mem�ria!\n");
        exit(-1);
    }
    //Ler os elementos:
    printf("Digite os elementos do vetor A:");
    for(i = 0; i<t; i++){
        printf("%A", &i);
        scanf("%f=", vetorA[i]);
    }
     printf("Digite os elementos do vetor B:");
    for(i = 0; i<t; i++){
        printf("%B", &i);
        scanf("%f=", vetorB[i]);
    }



return 0;
}
