#include <stdio.h>
#include <stdlib.h>

int *alocarMatriz(int l, int c);
void lerMatriz(int *m, int l, int c);
void mostrarMatriz(int *m, int l, int c);
void somarMatriz(int *x, int *y, int *z, int l, int c);

int *alocarMatriz(int l, int c) {
    int *m = (int *) malloc(l * c * sizeof(int));
    if (!m) {
        printf("Erro de aloca��o!\n");
        exit(-1);
    }
    return m;
}

void lerMatriz(int *m, int l, int c) {
    int i, j, k;
    for (i = 0; i < l; i++) {
        for (j = 0; j < c; j++) {
            k = i * c + j;
            printf("Elemento [%d][%d]: ", i, j);
            scanf("%d", (m + k));
        }
    }
    return;
}
void mostrarMatriz(int *m, int l, int c) {
    int i, j, k;
    printf("\n");
    for (i = 0; i < l; i++) {
        for (j = 0; j < c; j++) {
            k = i * c + j;
            printf("%d\t", *(m + k));
        }
        printf("\n");
    }
    return;
}
void somarMatriz(int *x, int *y, int *z, int l, int c) {
    int i, j, k;
    for (i = 0; i < l; i++) {
        for (j = 0; j < c; j++) {
            k = i * c + j;
            *(z + k) = *(x + k) + *(y + k);
        }
    }
    return;
}
int main() {
    int *a, *b, *c;
    int L, C;

    printf("Digite o n�mero de linhas e colunas: ");
    scanf("%d %d", &L, &C);

    a = alocarMatriz(L, C);
    b = alocarMatriz(L, C);
    c = alocarMatriz(L, C);

    printf("\n--- Matriz A ---\n");
    lerMatriz(a, L, C);

    printf("\n--- Matriz B ---\n");
    lerMatriz(b, L, C);

    somarMatriz(a, b, c, L, C);

    printf("\n--- Matriz A ---\n");
    mostrarMatriz(a, L, C);

    printf("\n--- Matriz B ---\n");
    mostrarMatriz(b, L, C);

    printf("\n--- Matriz Soma (A + B) ---\n");
    mostrarMatriz(c, L, C);

    free(a);
    free(b);
    free(c);

    return 0;
}
