#include <stdio.h>
int par (int n){
    if (n%2==0)
        return 0;
    else
        return 1;

}
int main (){
    int x;
    printf("Digite um n�:\n");
    scanf("%d", &x);
    if (par(x))
        printf("A funcao par retornou verdadeiro = %d\n", par(x));
    else
        printf("A funcao par retornou FALSO = %d\n", par(x));

return 0;
}
