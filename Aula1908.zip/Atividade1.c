//1. Fa�a um programa que leia a idade de uma pessoa expressa em anos, meses e dias e em uma
//fun��o mostre-a expressa apenas em dias.

#include <stdio.h>

void funcaoIdade(int anos, int meses, int dias);

int main() {
    int anos, meses, dias;

    printf("Digite sua idade:\n");
    printf("Anos: ");
    scanf("%d", &anos);

    printf("Meses: ");
    scanf("%d", &meses);

    printf("Dias: ");
    scanf("%d", &dias);

    // Chamada da fun��o
    funcaoIdade(anos, meses, dias);

    return 0;
}

// Defini��o da fun��o
void funcaoIdade(int anos, int meses, int dias) {
    int totalDias;
    totalDias = (anos * 365) + (meses * 30) + dias;
    printf("A sua idade em dias �: %d\n", totalDias);
}
