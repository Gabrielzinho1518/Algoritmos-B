#include <stdio.h>

void mostraPares(int v[], int tamanho);

int main(){
    int i;
    int v[10];
    printf("Digite 10 numeros inteiros:\n");
    for (i=0; i<10;i++)
        scanf("%i",&v[i]);

    mostraPares(v, 10);

    return 0;
}

void mostraPares(int v[], int tamanho){
    int i;
    for(i=0; i<tamanho; i++){
        if (v[i]%2==0){
            printf("%d na funcao  %d\n", v[i],i);
        }
    }
}
