/*  8- Escrever um programa que leia duas datas no formato dd/mm/aaaa e verifique qual data ocorre
primeiro. Use estruturas para armazenar os dados. Tamb�m � necess�rio o uso da fun��o atoi()
que converte uma string em um n�mero inteiro.
*/

#include <stdio.h>
struct data  {
    int dia;
    int mes;
    int ano;
};
struct data2 {
    int dia2;
    int mes2;
    int ano2;
};

int main(){
    char stringData1[9];
    struct data;
    struct data2;
    char aux[3];

    printf("Digite uma data dd//mm//aaaa\n");
    scanf("%s", stringData1);
    aux[0] = stringData1[0];
    aux [1] = stringData1[1];
    aux [2] = '\0';
    data.dia = atoi (aux);
    printf("Digite uma segunda data dd//mm//aaaa\n");
    data2.dia2 = atoi(aux);
    aux [0] = stringData2[3];
    aux [1] = stringData2[4];
    data2.mes2 = atoi(aux);
    aux[0] = stringData2[6];
    aux[1] = stringData2[7];
    data2.ano2 = atoi(aux);

    printf("%d dia(s), %d mes, %d ano", data.dia, data.mes, data.ano);
    printf("%d dia(s), %d mes, %d ano", data2.dia2, data2.mes2, data2.ano2);

    if (data1 < data2){
        printf("A data 1 vem antes da data 2");
    }
    else {
        printf("A data 2 vem antes da data 1");
    }

return 0;
}
