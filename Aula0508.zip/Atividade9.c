//9. Escrever um programa que l� um hor�rio hh:mm:ss e verifica se este est� correto
#include <stdio.h>
struct horario {
    int h;
    int min;
    int seg;
};
int main(){
    char stringHora[9];
    struct horario hora;
    char aux[3];

    printf("Digite um hor�rio hh:mm:ss\n");
    scanf("%s", stringHora);
    aux[0] = stringHora[0];
    aux [1] = stringHora [1];
    aux [2] = '\0';
    hora.h = atoi (aux);
    printf("Hora em inteiro: = %d\n", hora.h);
    hora.h = atoi(aux);
    aux [0] = stringHora[3];
    aux [1] = stringHora[4];
    hora.min = atoi(aux);
    aux[0] = stringHora[6];
    aux[1] = stringHora[7];
    hora.seg = atoi(aux);

    printf("%d hora(s), %d minuto(s), %d segundo(s)", hora.h, hora.min, hora.seg);

    if(hora.h < 24 && hora.h > -1 && hora.min < 60 && hora.seg < 60){
        printf("A Hora esta correta");
    }
    else {
        printf("A Hora esta incorreta");
    }


return 0;
}
