#include <stdio.h>
struct tipoAluno {
    char matricula[11];
    char nome[30];
    int anoIngresso;
    float mediaVestibular;

};
int main (){
    struct tipoAluno alunos[5];
    int i;

    printf("Digite a matricula (m�ximo 10 caracteres):");
    scanf("%s",  alunos[i].matricula);

    printf("Digite o nome do aluno:");
    scanf("% s", alunos[i].nome);

    printf("Digite o ano de ingresso:");
    scanf("%d", &alunos[i].anoIngresso);

    printf("Digite a m�dia do vestibular:");
    scanf("%f", &alunos[i].mediaVestibular);

    printf("\nDados do aluno:\n");
    for (i = 0; i < 5; i++){
    printf("Aluno %d", i + 1);
    printf("Matricula: %s\n", alunos[i].matricula);
    printf("Ano de ingresso: %d\n", alunos[i].nome);
    printf("M�dia do vestibular: %.2f\n", alunos[i].mediaVestibular);
    }

    return 0;
}
