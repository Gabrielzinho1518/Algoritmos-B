/* Escreva um programa que fa�a o controle das informa��es relativas aos funcion�rios de uma
determinada empresa. As informa��es que devem ser armazenadas s�o: Nome, Sal�rio, Cargo e
Idade. Defina a estrutura de dados e fa�a a leitura e exibi��o dos dados para um funcion�rio.
*/
#include <stdio.h>
struct Empresa{
    char nome[30];
    float salario;
    int cargo;
    int idade;
};

int main(){
    struct Empresa funcionario;

    printf("Digite o seu nome:\n");
    fgets(funcionario.nome, sizeof(funcionario.nome), stdin);
    scanf("%c", funcionario.nome);

    printf("Digite o seu sal�rio:\n");
    scanf("%f", &funcionario.salario);

    printf("Digite o seu cargo na empresa:\n");
    scanf("%d", &funcionario.cargo);

    printf("Digite a sua idade:\n");
    scanf("%d", &funcionario.idade);

return 0;
}
