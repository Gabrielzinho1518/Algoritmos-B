/* A loja VendeTudo possui 50 clientes. O gerente, para cada cliente, necessita armazenar o nome,
cidade onde mora, o total da compra e o m�s que o cliente comprou. Desenvolva o programa
para ler e mostrar os dados.
*/
#include <stdio.h>
struct VendeTudo {
    int clientes[50];
    char nome[30];
    int cidade;
    int total_da_compra;
    int mes_da_compra;

};
int main(){
    struct VendeTudo Clientes;
    int i;

    for(i = 0; i < 50; i++){
        printf("Clientes: %d\n", i + 1);

    printf("Digite o seu nome:\n");
    scanf("%s", Cliente[i].nome);

    printf("Digite a sua cidade:\n");
    scanf("%d", &Cliente[i].cidade);

    printf("Digite o total da sua compra:\n");
    scanf("%d", &Cliente[i].total_da_compra);

    printf("Digite o mes da sua compra:\n");
    scanf("d", &Cliente[i].mes_da_compra);

    printf("----- Dados dos Clientes -----\n");
    for (i = 0; i < 50; i++) {
        printf("Cliente %d:\n", i + 1);
        printf("Nome: %s\n", clientes[i].nome);
        printf("Cidade: %s\n", clientes[i].cidade);
        printf("Total da compra: R$ %.2f\n", clientes[i].total_da_compra);
        printf("Mes da compra: %d\n\n", clientes[i].mes_da_compra);
    }

return 0;
}
