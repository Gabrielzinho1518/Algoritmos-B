#include <stdio.h>

struct ponto{
    float x, y;

};

int main(){
struct ponto p1, p2, p3;

printf("Digite as coordenadas x e y do primeiro ponto:\n");
scanf("%f %f", &p1.x, &p1.y);

printf("Digite as coordenadas x e y do segundo ponto:\n");
scanf("%f %f", &p2.x, &p2.y);

printf("Digite as coordenadas x e y do terceiro ponto:\n");
scanf("%f %f", &p3.x, &p3.y);

if (p3.x >= p1.x && p3.x <= p2.x && p3.y >= p1.y && p3.y <= p2.y){
    printf("O ponto 3 esta dentro do retangulo");
} else {
    printf("O ponto 3 n�o esta dentro do retangulo");
}

return 0;
}
