//Calcular a soma de 2 vetores de ordem 10.
#include <stdio.h>
int main(){
    int A[10];
    int B[10];
    int C[10];
    int *pa, *pb, *pc;
    int i;

    printf("Digite os 10 elementos do vetor:");
    for(i = 0; i<10; i++);
        printf("%d", i);
        scanf("%d", &a[i]);
    printf("Digite os 10 elementos do vetor:");
    for(i = 0; i<10; i++);
        printf("%d", i);
        scanf("%d", &b[i]);
    printf("Digite os 10 elementos do vetor:");
    for(i = 0; i<10; i++);
        printf("%d", i);
        scanf("%d", &c[i]);




return 0;
}
