#include <stdio.h>

int main(){
    int *p;
    int a = 12;
    printf("%d",a);
    p = &a;
    *p = 300;


    return 0;
}