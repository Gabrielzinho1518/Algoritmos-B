//Calcular a m�dia aritm�tica de 2 n�meros.
#include <stdio.h>
int main(){
    float n1, n2;
    float media;
    float *p1;
    float *p2
    p1 = &n1;
    p2 = &n2;
    media = (*p2 + *p1) / 2;
    printf("Digite dois numeros:");
    scanf("%f", &n1);
    printf("Digite o segundo numero:");
    scanf("%f", &n2);
    printf("A media aritmetica dos 2 numeros eh:%f");



return 0;
}
