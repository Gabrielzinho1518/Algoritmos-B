//Ler 1 palavra e inverte-la,
//Dentro da mesma string

#include <stdio.h>
int main(){
    char p[30], *pi, *pf;
    pi = pf = p;
}
