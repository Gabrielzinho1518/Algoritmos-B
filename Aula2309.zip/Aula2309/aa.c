//Ler 1 palavra e inverte-la,
//Dentro da mesma string

#include <stdio.h>
int main(){
    char p[30], *pi, *pf, aux;
    printf("Digite uma palavra:");
    scanf("%s", p);
    pi = pf = p;
    for ( ; *pf; pf++);
    pf--;
    
    for(  ; pi<pf; pi++, pf--){
        aux = *pf;
        *pf = *pi;
        *pi = aux;
        
    }
    printf("Palavra invertida %s", p);
    return 0;
}

