#include <stdio.h>
#include <string.h>
int main(){
    char s[50], *ps;
    int i;
    ps = s;
    printf("Escreva uma palavra:");
    scanf("%s", ps);
    for(i=0; s[i]!='/0'; i++)
        printf("%c\n", s[i]);

return 0;
}
