#include <stdio.h>
void lerMatriz (int *pm){
    int i, j, k;

    for(i=0; i<3; i++)
        for(j=0; j<3; j++){
            printf("Digite duas matrizes:\n");
            printf("m[%d][%d]=",i, j);
            k = i*3+j;
            scanf("%d",(pm+k));
            }
}
void lerVetor(int *pm){
    int i, j, k;
    for(i=0; i<3; i++)
        for(j=0; j<3; j++){
            printf("Digite dois vetores:\n");
            printf("m[%d][%d]=",i, j);
            k = i*3+j;
            scanf("%d",(pm+k));
            }
}
void mostrarMatriz (int *pm){
    int i, j, k;
    for(i=0; i<3; i++){
        for(j=0; j<3; j++){
            k=i * 3+j;
            printf("%d\t", *(pm+k));
        }
        printf("\n");
    }
return;
}

int main(){
    int v[10], m[3][3];
    lerVetor(v);
    lerMatriz(m);
    mostrarMatriz(m);

}
